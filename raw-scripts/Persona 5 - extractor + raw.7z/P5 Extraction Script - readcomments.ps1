# requires https://github.com/TGEnigma/AtlusFileSystemLibrary for PAKPack
# and a (!)RECENT BUILD(!) of https://github.com/TGEnigma/Atlus-Script-Tools
# if you don't use a recent build, this won't work at all. the v1.0 in github is too old.
# also, modify any directories to whatever you are using (ofc).
# lastly, make sure to use powershell core 7+, stock windows powershell garbles most CJK UTF-8 by default.


# runs PAKPack against the entire p5 ROM, placed at the input directory *if the directory doesn't exist, make it first
Get-ChildItem -Path "C:\Tools\AtlusFileSystemLibrary\input\*" -recurse -Include *.PAK |
ForEach-Object {
    &"C:\Tools\AtlusFileSystemLibrary\PAKPack.exe" "unpack" $_.FullName "C:\Tools\AtlusFileSystemLibrary\output\"
}

# merges both the loose scripts and the extracted scripts into single dir
Get-ChildItem -Path "C:\Tools\AtlusFileSystemLibrary\input\*" -Include *.bf,*.bmd -Recurse |
Copy-Item -Destination "C:\Tools\AtlusFileSystemLibrary\mergedout"
Get-ChildItem -Path "C:\Tools\AtlusFileSystemLibrary\output\*" -Include *.bf,*.bmd -Recurse |
Copy-Item -Destination "C:\Tools\AtlusFileSystemLibrary\mergedout"

# sets destination path and runs the script extractor, outputs to MessageScriptDump.txt in dest dir
Set-Location -Path "C:\Tools\AtlusScriptToolchain\output"
&"C:\Tools\AtlusScriptToolchain\AtlusMessageScriptExtractor.exe" "-path" "C:\Tools\AtlusFileSystemLibrary\mergedout\" "-enc" "p5"